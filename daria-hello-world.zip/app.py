from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def hello_world():
    return render_template('index.html')

@app.route('/api/health')
def health_check():
    return {"status": "healthy", "message": "Daria Hello World API is running"}

if __name__ == '__main__':
    print("Starting Daria Hello World on port 5000")
    print("Visit http://127.0.0.1:5000 to see the app")
    app.run(host='0.0.0.0', port=5000) 
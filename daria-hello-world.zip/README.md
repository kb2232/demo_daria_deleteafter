# Daria Hello World

A simple Hello World application for testing AWS deployment of the Daria Interview Tool.

## Local Development

1. Clone this repository
2. Create a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
4. Run the application:
   ```
   python app.py
   ```
5. Visit http://127.0.0.1:5000 in your browser

## AWS Deployment

This application is designed to be deployed to AWS Elastic Beanstalk or AWS EC2.

### Elastic Beanstalk Deployment

1. Install the EB CLI:
   ```
   pip install awsebcli
   ```
2. Initialize EB application:
   ```
   eb init
   ```
3. Create an environment and deploy:
   ```
   eb create
   ```
4. For subsequent deployments:
   ```
   eb deploy
   ```

### EC2 Deployment

Instructions for manual EC2 deployment are included in the deployment guide. 
# Daria Hello World - AWS Deployment Guide

This guide provides step-by-step instructions for deploying the Daria Hello World app to AWS.

## AWS EC2 Deployment

### Prerequisites

1. An AWS account
2. Basic knowledge of AWS services
3. SSH client installed on your local machine

### Step 1: Launch an EC2 Instance

1. Sign in to the AWS Management Console
2. Navigate to EC2 Dashboard
3. Click "Launch Instance"
4. Select Amazon Linux 2023 AMI
5. Choose t2.micro instance type (free tier eligible)
6. Configure instance details (use defaults unless you have specific requirements)
7. Add storage (default 8GB is sufficient)
8. Add tags (optional)
9. Configure security group:
   - Allow SSH (port 22) from your IP
   - Allow HTTP (port 80) from anywhere
   - Allow HTTPS (port 443) from anywhere
10. Review and Launch
11. Create or select an existing key pair and download it
12. Launch instance

### Step 2: Connect to your EC2 Instance

```bash
chmod 400 your-key-pair.pem
ssh -i your-key-pair.pem ec2-user@your-instance-public-dns
```

### Step 3: Set up the Environment

```bash
# Update system packages
sudo yum update -y

# Install Python and pip
sudo yum install python3 python3-pip git -y

# Install virtualenv
pip3 install virtualenv

# Clone the repository (if using Git)
git clone https://your-repository-url.git
# OR upload files via SCP
# scp -i your-key-pair.pem -r ./DariaHelloWorld ec2-user@your-instance-public-dns:~

# Navigate to project directory
cd DariaHelloWorld

# Create and activate virtual environment
python3 -m virtualenv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Install Gunicorn
pip install gunicorn
```

### Step 4: Run the Application with Gunicorn

Create a systemd service file to run the application:

```bash
sudo nano /etc/systemd/system/daria.service
```

Add the following content:

```
[Unit]
Description=Daria Hello World
After=network.target

[Service]
User=ec2-user
WorkingDirectory=/home/ec2-user/DariaHelloWorld
ExecStart=/home/ec2-user/DariaHelloWorld/venv/bin/gunicorn -b 0.0.0.0:8000 app:app
Restart=always

[Install]
WantedBy=multi-user.target
```

Start and enable the service:

```bash
sudo systemctl start daria
sudo systemctl enable daria
```

### Step 5: Set Up Nginx as a Reverse Proxy

Install and configure Nginx:

```bash
sudo yum install nginx -y
sudo nano /etc/nginx/conf.d/daria.conf
```

Add the following configuration:

```
server {
    listen 80;
    server_name your_domain_or_ip;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Start and enable Nginx:

```bash
sudo systemctl start nginx
sudo systemctl enable nginx
```

### Step 6: Access Your Application

Open a browser and visit your EC2 instance's public IP or domain name. You should see the Daria Hello World application running.

### Additional Security Recommendations

1. Set up a domain name and SSL certificate using AWS Certificate Manager
2. Configure AWS Firewall rules to restrict access
3. Set up CloudWatch for monitoring
4. Consider using AWS Elastic Load Balancer for better availability 